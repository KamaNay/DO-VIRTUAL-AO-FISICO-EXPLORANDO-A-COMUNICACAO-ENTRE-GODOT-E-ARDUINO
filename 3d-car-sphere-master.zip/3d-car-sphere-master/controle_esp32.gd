extends Node

# Cria o objeto que vai escutar a rede local para receber pacotes UDP
var udp := PacketPeerUDP.new()
const PORT = 4242

# Define a sensibilidade da inclinação física (Filtro Anti-Tremor do jogador)
# 0.25 significa que movimentos menores que 25% da gravidade são ignorados.
const ZONA_MORTA = 0.25 

func _ready():
	# Abre a porta do PC para começar a escutar o ESP32
	var erro = udp.bind(PORT)
	if erro == OK:
		print("Pronto! Escutando o controle do ESP32 na porta: ", PORT)
	else:
		print("Erro ao tentar escutar a porta UDP.")

# O _process roda a cada frame do jogo (geralmente 60 vezes por segundo)
func _process(_delta):
	# Se existe algum pacote de dados esperando na rede...
	if udp.get_available_packet_count() > 0:
		# Lê os bytes recebidos e converte de volta para texto (String)
		var pacote = udp.get_packet().get_string_from_utf8()
		_processar_comandos(pacote)

func _processar_comandos(dados: String):
	# O ESP32 envia no formato "Y,X" (ex: "0.50,-0.10"). 
	# O .split() corta a string onde tem a vírgula e cria uma lista (Array) de 2 posições.
	var eixos = dados.split(",")
	
	if eixos.size() >= 2:
		# Pega os valores, transforma em números flutuantes e inverte o sinal (multiplicando por -1)
		# para casar com os eixos do Godot e a posição física da tela voltada para o rosto.
		var inclinacao_y = eixos[0].to_float() * -1.0 # Eixo Y: Acelerar e Frear
		var inclinacao_x = eixos[1].to_float() * -1.0 # Eixo X: Curva Esquerda/Direita
		
		# --- LÓGICA DE ACELERAR E FREAR (EIXO Y) ---
		# Se a placa for inclinada forte para a frente (Acelerar)
		if inclinacao_y < -ZONA_MORTA:
			Input.action_press("accelerate")
			Input.action_release("brake")
		# Se a placa for inclinada forte para trás (Frear/Ré)
		elif inclinacao_y > ZONA_MORTA:
			Input.action_press("brake")
			Input.action_release("accelerate")
		# Se a placa estiver reta (dentro da zona morta), o carro rola livremente
		else:
			Input.action_release("accelerate")
			Input.action_release("brake")

		# --- LÓGICA DE DIREÇÃO (EIXO X) ---
		# Se a placa girar como um volante para a direita
		if inclinacao_x > ZONA_MORTA:
			Input.action_press("steer_right")
			Input.action_release("steer_left")
		# Se a placa girar como um volante para a esquerda
		elif inclinacao_x < -ZONA_MORTA:
			Input.action_press("steer_left")
			Input.action_release("steer_right")
		# Se a placa estiver reta, a direção volta para o centro
		else:
			Input.action_release("steer_right")
			Input.action_release("steer_left")
