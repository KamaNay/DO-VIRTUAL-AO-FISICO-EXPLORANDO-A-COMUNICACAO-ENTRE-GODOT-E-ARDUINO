extends RigidBody3D

# --- VARIÁVEIS DE CONFIGURAÇÃO DO CARRO (SPHERE CONTROLLER) ---
var sphere_offset = Vector3.DOWN # Ajuste do centro de gravidade visual
var acceleration = 35.0          # Força do motor
var steering = 19.0              # Ângulo máximo de viragem (em graus)
var turn_speed = 4.0             # Velocidade que a malha do carro gira visualmente
var turn_stop_limit = 0.75       # O carro não vira se a velocidade for muito baixa
var body_tilt = 35               # Inclinação lateral (Rolagem da carroceria nas curvas)

# Variáveis que receberão as inputs (Teclado ou ESP32)
var speed_input = 0
var turn_input = 0

# --- CONFIGURAÇÃO DE REDE DO ESP32 ---
var esp32_ip = "192.168.15.7" # O IP do próprio ESP32 na rede
var porta_esp32 = 4242        # A mesma porta configurada no Arduino

# Objeto para enviar pacotes de dados pela rede (UDP)
var udp := PacketPeerUDP.new() 

# --- REFERÊNCIAS AOS NÓS DA CENA ---
@onready var car_mesh = $CarMesh
@onready var body_mesh = $CarMesh/suv2
@onready var ground_ray = $CarMesh/RayCast3D
@onready var right_wheel = $CarMesh/suv2/wheel_frontRight
@onready var left_wheel = $CarMesh/suv2/wheel_frontLeft

# Lógica de Física Base: Mantém a malha visual do carro colada à esfera invisível (RigidBody)
func _physics_process(delta):
	car_mesh.position = position + sphere_offset
	# Se o carro estiver no chão, aplica a força de aceleração para frente (eixo -Z da malha)
	if ground_ray.is_colliding():
		apply_central_force(-car_mesh.global_transform.basis.z * speed_input)
	
func _process(delta):
	# --- TELEMETRIA PARA O CONTROLE ---
	# Calcula a velocidade linear em magnitude (metros por segundo) e multiplica por 3.6 para Km/h
	var velocidade_kmh = linear_velocity.length() * 3.6
	enviar_velocidade_para_esp32(velocidade_kmh)
	
	# Se estiver no ar, ignora os inputs (não pode virar nem acelerar no ar)
	if not ground_ray.is_colliding():
		return
		
	# Captura os comandos do sistema de Input Map do Godot
	speed_input = Input.get_axis("brake", "accelerate") * acceleration
	turn_input = Input.get_axis("steer_right", "steer_left") * deg_to_rad(steering)
	
	# Gira fisicamente os pneus dianteiros na tela
	right_wheel.rotation.y = turn_input
	left_wheel.rotation.y = turn_input
	
	# Lógica visual de virar o corpo do carro e simular rolagem (Tilt)
	if linear_velocity.length() > turn_stop_limit:
		var new_basis = car_mesh.global_transform.basis.rotated(car_mesh.global_transform.basis.y, turn_input)
		car_mesh.global_transform.basis = car_mesh.global_transform.basis.slerp(new_basis, turn_speed * delta)
		car_mesh.global_transform = car_mesh.global_transform.orthonormalized()
		
		# Aplica a inclinação lateral da carroceria de acordo com a velocidade e curva
		var t = -turn_input * linear_velocity.length() / body_tilt
		body_mesh.rotation.z = lerp(body_mesh.rotation.z, t, 5.0 * delta)
		
		# Alinha o carro com a inclinação do chão
		if ground_ray.is_colliding():
			var n = ground_ray.get_collision_normal()
			var xform = align_with_y(car_mesh.global_transform, n)
			car_mesh.global_transform = car_mesh.global_transform.interpolate_with(xform, 10.0 * delta)

# Função auxiliar para alinhar a rotação do veículo baseada no vetor Normal do chão
func align_with_y(xform, new_y):
	xform.basis.y = new_y
	xform.basis.x = -xform.basis.z.cross(new_y)
	return xform.orthonormalized()

# Função que empacota o número inteiro de Km/h e envia via UDP para o visor do ESP32
func enviar_velocidade_para_esp32(velocidade: float):
	var v_str = str(int(velocidade)) # Converte para número sem vírgula
	udp.set_dest_address(esp32_ip, porta_esp32)
	udp.put_packet(v_str.to_utf8_buffer()) # Envia em formato de bytes
